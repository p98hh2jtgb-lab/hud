HUD PRO v5.1 — VEHICLE CIRCLES ON/OFF + FUTURA SURVIVAL FONT

RISET NE v5.1
1) ON/OFF per rrathet e makinave (lart):
   - KRYESORE tab -> "Rrathet e makinave (lart) ON/OFF"
   - MAKINAT tab -> "Shfaq rrumullaket e makinave"
   - Kur e fik, ne ekran mbetet veq Survival Chance.
   - Kur don me i shtu prap rrathet nalt, boje ON.
   - Ruhet automatikisht + eshte edhe ne Presets.
   - Bonus: keybind i ri ne Options -> Controls -> "HUD PRO: Toggle vehicle circles".

2) Survival Chance me Futura:
   - Default: Futura Extra Bold.
   - SURVIVAL tab -> Typography & FX -> "Fonti i Survival":
     Futura Extra Bold / Futura Bold / System (Arial Narrow).
   - SHENIM: Futura duhet me e pas te instaluar ne Windows.
     Nese s'e ke, HUD-i bie automatikisht ne Century Gothic
     (shume i ngjashem me Futuren), pastaj Arial Narrow.

INSTALL
1. Fshije/çaktivizo CreatorPack_v5.0_UNICODE_INLINE.zip e vjeter.
2. Qite CreatorPack_v5.1_VEHICLES_TOGGLE_FUTURA.zip direkt ne Documents/BeamNG.drive/mods.
3. Mos e ekstrakto. Restart BeamNG ose Reload UI.

BAZA v5.0
Statusi si tekst inline ekzakt:
- SAFE 😎
- CAUTION 😬
- DANGER 😰
- CRITICAL 😵
- NO CHANCE 💀
+ v4.7 Smooth Pop dhe v4.6 color/alignment fixes.
