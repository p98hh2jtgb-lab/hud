SURVIVAL ONLY v5.2 — VETEM SURVIVAL CHANCE

QKA KA BRENDA
- Vetem overlay-i i Survival Chance (titulli + perqindja + statusi + emoji).
- Fonti: Futura Extra Bold (default). Nderrohet ne panel:
  Futura Extra Bold / Futura Bold / System.
- SHENIM: Futuren duhet me e pas te instaluar ne Windows,
  perndryshe bie automatikisht ne Century Gothic (te ngjashem).

QKA U FSHI
- Rrathet e makinave, damage rings, PASS/FAIL, guidat 9:16,
  presets, export/import, statistikat — krejt jashte.
- Tasta: H = hap/mbyll panelin, G = reset run-i (demi + survival).
- Ne Options -> Controls i ke vetem dy bindings:
  "SURVIVAL: Reset run" dhe "SURVIVAL: Toggle config panel".

PANELI (E RENDESISHME)
- Paneli mbyllet me X ose me butonin "Hide panel".
- Kur mbyllet, nalt djathtas del butoni rrethes me shenjen e
  settings qe pulson lehte — klikoje edhe paneli hapet prap.
- Ose shtyp H ne tastiere. S'mund te "humbet" me paneli.

INSTALL (LEXOJE)
1. FSHIJE prej Documents/BeamNG.drive/mods CDO ZIP te vjeter
   CreatorPack (v5.0, v5.1, cfaredo). Leje VEC kete:
   CreatorPack_v5.2_SURVIVAL_ONLY.zip
   (Dy versione njekohesisht = konflikt, prandaj te ishte prishur.)
2. Mos e ekstrakto zip-in.
3. Restart BeamNG ose Reload UI.
4. Settings te vjetra NUK merren parasysh — ky version fillon paster.

STATUSI
SAFE, CAUTION, DANGER, CRITICAL, NO CHANCE
me emoji inline, ngjyra dinamike dhe animacione Smooth Pop.
