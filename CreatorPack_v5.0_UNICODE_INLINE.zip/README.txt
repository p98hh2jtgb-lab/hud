HUD PRO v5.0 — TRUE INLINE STATUS EMOJI

INSTALL
1. Disable/remove the older CreatorPack ZIP/folder.
2. Put CreatorPack_v5.0_UNICODE_INLINE.zip directly in Documents/BeamNG.drive/mods.
3. Do not extract. Restart BeamNG or Reload UI.

FIX
The generated PNG emoji assets were removed. Status now renders as exact inline text:
- SAFE 😎
- CAUTION 😬
- DANGER 😰
- CRITICAL 😵
- NO CHANCE 💀

The status text is forced visible whenever Emoji Mood is enabled, so an old hidden-status
or Replace-only setting cannot leave only the emoji on screen. Migration reads the actual
saved config and forces SAFE + Emoji mode once. Options remain for SAFE 😎 or 😎 SAFE,
emoji size and status-change Pop.

Emoji glyph appearance is provided by the color-emoji font available in BeamNG/Windows CEF.
All v4.7 Smooth Pop and v4.6 color/alignment fixes remain.
